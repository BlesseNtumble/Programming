# -*- coding: utf-8 -*-
# 6 Вариант. Задание 144б

n = 0
an = []
af = []
while n < 1:
    print('Введите n:'); n = int(input())
    
u = 0
f = 0
for i in range(n):
    if i == 1: 
        u = 1
        f = 1
    if i > 1: 
        u = an[i-1] + an[i-2]
        f = af[i-1] + af[i-2] + an[i-2]
    an.append(u)
    af.append(f)
    
print('U:', an)    
print('F:', af)
