# -*- coding: utf-8 -*-
# 6 Вариант. Задание 160
import math


n = 0
l = 0
while n <= 0:
    print('Введите n:'); n = int(input())
    
alfa = 0
s = 0
m = 0
for i in range(n):
    print('Введите угол в градусах %s линии:' % (i+1)); alfa = float(input())
    print('Введите длину %s линии:' % (i+1)); l = float(input())
    
    alfa = alfa * math.pi / 180
    x = l * math.cos(alfa)
    s = s + x
    y = l * math.sin(alfa)
    m = m + y
print('Координаты: X:%s Y:%s' % (int(s), int(m)))
    