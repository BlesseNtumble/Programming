# -*- coding: utf-8 -*-
# 6 Вариант. Задание 178
import random

n = 0
while n <= 0:
    print('Введите n:'); n = int(input())
    
m = []
res = []
res1 = []
for i in range(n):
    m.append(random.randint(0, 999))
    if i % 2 == 0:
        res.append(m[i])
    if m[i] % 2 != 0:
        res1.append(m[i])
        
print('Общая последовательность:', m)
print('Четные порядковые номера:', res)
print('Нечетные числа:', res1)