# -*- coding: utf-8 -*-
# 6 Вариант. Задание 137e

an = []
print('Введите n:'); n = int(input())

fact = 1
res = 0

for i in range(1, n+1): 
    print('Введите a[%s]:' % (i - 1)); an.append(float(input()))
    fact = fact * i    
    res += an[i-1] + fact
print('Factorial: ', fact)
print('Result: ', res)
    